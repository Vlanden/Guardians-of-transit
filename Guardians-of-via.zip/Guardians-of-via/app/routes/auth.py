from flask import Blueprint
from app.controllers.auth_controller import login_view, recover_view, register_view

# Creamos el Blueprint con el nombre 'auth' y prefijo opcional si se necesita.
auth_bp = Blueprint('auth', __name__, url_prefix='/auth')

# Definimos las rutas y las funciones asociadas
auth_bp.add_url_rule('/login', view_func=login_view, methods=['GET', 'POST'])
auth_bp.add_url_rule('/register', view_func=register_view, methods=['GET', 'POST'])
auth_bp.add_url_rule('/recover', view_func=recover_view, methods=['GET', 'POST'])
